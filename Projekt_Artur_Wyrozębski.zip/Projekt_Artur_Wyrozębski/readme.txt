Sposób uruchamiania programów

Aby wykonać program obliczający wynik, należy uruchomić skrypt script.py znajdujący się w folderze Project. (najlepiej komendą: python3.7 Project/script.py). Należy następnie postępować zgodnie z tekstem zwracanym przez program.

Aby wykonać profilowanie pod względem czasowym, należy uruchomić skrypt profiling.py znajdujący się w folderze Project. (najlepiej komendą: python3.7 Project/profiling.py). Należy następnie postępować zgodnie z tekstem zwracanym przez program.

Aby wykonać profilowanie pod względem pamięciowym, należy uruchomić skrypt memory_profiling.py znajdujący się w folderze Project. (najlepiej komendą: python3.7 Project/memory_profiling.py). Należy następnie postępować zgodnie z tekstem zwracanym przez program.
